import "./globals.css"
import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import { ChefHat, Zap } from 'lucide-react'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'InstaChef AI — Cooking Commerce Agent',
  description: 'Turn any recipe into a Swiggy Instamart grocery order in seconds.',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <div className="min-h-screen flex flex-col">
          {/* ── Swiggy-style Header ──────────────────────────── */}
          <header className="sticky top-0 z-50 bg-white border-b border-brand-border shadow-card">
            <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
              {/* Logo */}
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 bg-swiggy rounded-xl flex items-center justify-center shadow-sm">
                  <svg viewBox="0 0 24 24" className="w-5 h-5 text-white" fill="currentColor">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/>
                  </svg>
                </div>
                <div>
                  <h1 className="text-lg font-bold text-brand-dark leading-none">
                    InstaChef AI
                  </h1>
                  <p className="text-[10px] text-brand-muted font-medium tracking-wider uppercase mt-0.5">
                    Cooking Commerce Agent
                  </p>
                </div>
              </div>

              {/* Status pill */}
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1.5 bg-green-50 text-green-700 px-3 py-1.5 rounded-full text-xs font-medium">
                  <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse-slow"></span>
                  Connected
                </div>
              </div>
            </div>
          </header>

          {/* ── Main Content ─────────────────────────────────── */}
          <main className="flex-1 max-w-5xl w-full mx-auto px-4 py-6">
            {children}
          </main>

          {/* ── Footer ───────────────────────────────────────── */}
          <footer className="border-t border-brand-border bg-white py-4">
            <div className="max-w-5xl mx-auto px-4 flex items-center justify-between">
              <p className="text-xs text-brand-muted">
                Powered by Swiggy MCP • NVIDIA Nemotron
              </p>
              <p className="text-xs text-brand-muted">
                Built for Swiggy MCP Hackathon 2026
              </p>
            </div>
          </footer>
        </div>
      </body>
    </html>
  )
}
