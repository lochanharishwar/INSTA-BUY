import { useState } from 'react'
import { useStore } from '../../lib/store'
import { api } from '../../lib/api'
import { ChevronDown, ChevronUp, Leaf, AlertTriangle, PackageCheck, ShoppingCart, ArrowRight, Info, Trash2 } from 'lucide-react'

const CONFIDENCE_BADGE: Record<string, { label: string; color: string; bg: string; border: string }> = {
  high:        { label: 'High Match',    color: 'text-green-700',  bg: 'bg-green-50',  border: 'border-green-200' },
  medium:      { label: 'Partial Match', color: 'text-amber-700',  bg: 'bg-amber-50',  border: 'border-amber-200' },
  low:         { label: 'Low Match',     color: 'text-red-700',    bg: 'bg-red-50',    border: 'border-red-200' },
  substitute:  { label: 'Substitute',    color: 'text-blue-700',   bg: 'bg-blue-50',   border: 'border-blue-200' },
  unavailable: { label: 'Unavailable',   color: 'text-gray-600',   bg: 'bg-gray-50',   border: 'border-gray-200' },
  pantry:      { label: 'Pantry Item',   color: 'text-indigo-700', bg: 'bg-indigo-50',  border: 'border-indigo-200' },
}

const CONFIDENCE_DOT: Record<string, string> = {
  high: 'bg-green-500', medium: 'bg-amber-500', low: 'bg-red-500',
  substitute: 'bg-blue-500', unavailable: 'bg-gray-400', pantry: 'bg-indigo-500',
}

export default function CartReview() {
  const { session_id, cart_proposal, setScreen } = useStore()
  const [items, setItems] = useState(cart_proposal?.cart_items || [])
  const [loading, setLoading] = useState(false)
  const [expandedIdx, setExpandedIdx] = useState<number | null>(null)

  if (!cart_proposal) return null;

  const handleRemove = (index: number) => {
    const newItems = [...items];
    newItems.splice(index, 1);
    setItems(newItems);
  }

  const handleConfirm = async () => {
    setLoading(true);
    try {
      const buyableItems = items.filter((i: any) => i.spin_id);
      await api.confirmCart(session_id, buyableItems);
      setScreen('tracking');
    } catch (err: any) {
      alert(err.message || 'Error placing order');
    } finally {
      setLoading(false);
    }
  }

  const buyableItems = items.filter((i: any) => i.spin_id);
  const pantryItems = items.filter((i: any) => i.confidence === 'pantry');
  const unavailableItems = items.filter((i: any) => i.confidence === 'unavailable');

  const total = buyableItems.reduce((sum: number, i: any) => sum + (i.product_price * (i.quantity || 1)), 0);
  const avgWaste = buyableItems.length > 0
    ? buyableItems.reduce((sum: number, i: any) => sum + (i.waste_pct || 0), 0) / buyableItems.length
    : 0;

  return (
    <div className="pb-28 animate-fade-in">
      {/* Header */}
      <div className="mb-6 mt-4">
        <h2 className="text-2xl font-bold text-brand-dark mb-1">Review Your Cart</h2>
        <p className="text-sm text-brand-subtle">AI-optimized basket for your recipe</p>
      </div>

      {/* Metrics strip */}
      <div className="grid grid-cols-4 gap-3 mb-5">
        {[
          { label: 'Items', value: String(buyableItems.length), accent: 'text-brand-dark' },
          { label: 'Total', value: `₹${total}`, accent: 'text-swiggy' },
          { label: 'Waste', value: `${avgWaste.toFixed(0)}%`, accent: avgWaste > 30 ? 'text-amber-600' : 'text-green-600' },
          { label: 'Pantry Saved', value: String(pantryItems.length), accent: 'text-indigo-600' },
        ].map(m => (
          <div key={m.label} className="swiggy-card p-3.5 text-center">
            <p className="text-[10px] text-brand-muted uppercase tracking-wider font-medium">{m.label}</p>
            <p className={`text-xl font-bold mt-0.5 ${m.accent}`}>{m.value}</p>
          </div>
        ))}
      </div>

      {/* Pantry items */}
      {pantryItems.length > 0 && (
        <div className="mb-4 bg-indigo-50 border border-indigo-100 rounded-2xl p-4 animate-slide-up">
          <div className="flex items-center gap-2 mb-2">
            <Leaf className="w-4 h-4 text-indigo-600" />
            <h3 className="text-sm font-semibold text-indigo-800">Pantry Staples — Skipped</h3>
          </div>
          <div className="flex flex-wrap gap-2">
            {pantryItems.map((item: any, i: number) => (
              <span key={i} className="text-xs bg-white px-2.5 py-1 rounded-full text-indigo-700 border border-indigo-200 font-medium">
                {item.ingredient_name}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Unavailable items */}
      {unavailableItems.length > 0 && (
        <div className="mb-4 bg-amber-50 border border-amber-100 rounded-2xl p-4 animate-slide-up">
          <div className="flex items-center gap-2 mb-2">
            <AlertTriangle className="w-4 h-4 text-amber-600" />
            <h3 className="text-sm font-semibold text-amber-800">Not Found on Instamart</h3>
          </div>
          <div className="flex flex-wrap gap-2">
            {unavailableItems.map((item: any, i: number) => (
              <span key={i} className="text-xs bg-white px-2.5 py-1 rounded-full text-amber-700 border border-amber-200 font-medium">
                {item.ingredient_name}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Cart items */}
      <div className="space-y-3">
        {buyableItems.map((item: any, i: number) => {
          const badge = CONFIDENCE_BADGE[item.confidence] || CONFIDENCE_BADGE.medium;
          const dot = CONFIDENCE_DOT[item.confidence] || 'bg-gray-400';
          const isExpanded = expandedIdx === i;

          return (
            <div key={i} className="swiggy-card overflow-hidden animate-slide-up" style={{ animationDelay: `${i * 50}ms` }}>
              <div className="p-4 flex items-start gap-3">
                {/* Product image */}
                <div className="w-16 h-16 bg-brand-bg rounded-xl overflow-hidden shrink-0 flex items-center justify-center border border-brand-border">
                  {item.image_url ? (
                    <img src={item.image_url} alt={item.product_name} className="w-full h-full object-cover" />
                  ) : (
                    <ShoppingCart className="w-6 h-6 text-brand-muted" />
                  )}
                </div>

                {/* Details */}
                <div className="flex-grow min-w-0">
                  <div className="flex justify-between items-start">
                    <div className="min-w-0 pr-2">
                      <p className="text-[11px] text-brand-muted truncate">
                        {item.ingredient_name} • {item.ingredient_quantity_display}
                      </p>
                      <h3 className="font-bold text-brand-dark text-sm mt-0.5 leading-snug">{item.product_name}</h3>
                      <p className="text-xs text-brand-subtle mt-0.5">
                        {item.product_quantity_display}
                        {item.quantity > 1 && <span className="text-swiggy font-medium"> × {item.quantity}</span>}
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="font-bold text-brand-dark text-base">₹{item.product_price * (item.quantity || 1)}</p>
                    </div>
                  </div>

                  {/* Badges row */}
                  <div className="flex items-center gap-2 mt-2 flex-wrap">
                    <span className={`swiggy-badge ${badge.bg} ${badge.color} ${badge.border}`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${dot}`}></span>
                      {badge.label}
                    </span>
                    {item.waste_pct > 0 && (
                      <span className="text-[11px] text-brand-muted">
                        {item.waste_pct}% waste
                      </span>
                    )}
                    {/* Intelligence Badges */}
                    {item.selection_reasons?.some((r: string) => r.includes("Your go-to item")) && (
                      <span className="swiggy-badge bg-violet-50 text-violet-700 border-violet-200">
                        ⭐ Go-to Item
                      </span>
                    )}
                    {item.selection_reasons?.some((r: string) => r.includes("Your usual brand")) && (
                      <span className="swiggy-badge bg-pink-50 text-pink-700 border-pink-200">
                        ❤️ Usual Brand
                      </span>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex items-center justify-between mt-2.5">
                    <button
                      onClick={() => setExpandedIdx(isExpanded ? null : i)}
                      className="text-xs text-swiggy font-medium hover:text-swiggy-700 flex items-center gap-1 transition"
                    >
                      <Info className="w-3 h-3" />
                      Why this?
                      {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                    </button>
                    <button
                      onClick={() => handleRemove(items.indexOf(item))}
                      className="text-xs text-red-400 hover:text-red-600 flex items-center gap-1 transition"
                    >
                      <Trash2 className="w-3 h-3" />
                      Remove
                    </button>
                  </div>
                </div>
              </div>

              {/* Expanded reasoning */}
              {isExpanded && (
                <div className="border-t border-brand-border bg-brand-bg/50 px-5 py-3.5 space-y-2.5 animate-slide-up">
                  {item.selection_reasons?.length > 0 && (
                    <div>
                      <p className="text-[11px] font-semibold text-brand-subtle uppercase tracking-wider mb-1.5">Selection Reasoning</p>
                      <ul className="space-y-1">
                        {item.selection_reasons.map((reason: string, ri: number) => (
                          <li key={ri} className="text-xs text-brand-text flex items-start gap-2">
                            <PackageCheck className="w-3.5 h-3.5 text-green-500 shrink-0 mt-0.5" />
                            {reason}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {item.alternatives?.length > 0 && (
                    <div>
                      <p className="text-[11px] font-semibold text-brand-subtle uppercase tracking-wider mb-1.5">Alternatives</p>
                      {item.alternatives.slice(0, 2).map((alt: any, ai: number) => (
                        <div key={ai} className="text-xs text-brand-subtle flex items-center justify-between py-1 border-b border-brand-border/50 last:border-0">
                          <span>{alt.product_name} ({alt.product_quantity_display})</span>
                          <span className="font-medium">₹{alt.product_price}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )
        })}
      </div>

      {/* Sticky checkout bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-brand-border shadow-float z-50">
        <div className="max-w-5xl mx-auto px-4 py-3 flex justify-between items-center">
          <div>
            <p className="text-[11px] text-brand-muted uppercase tracking-wider font-medium">Total</p>
            <p className="text-2xl font-bold text-brand-dark">₹{total}</p>
          </div>
          <button 
            onClick={handleConfirm}
            disabled={loading || buyableItems.length === 0}
            className="swiggy-btn-primary px-8 py-3.5 text-base flex items-center gap-2"
          >
            {loading ? (
              <>
                <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Placing Order...
              </>
            ) : (
              <>
                Place Order ({buyableItems.length})
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  )
}
