import { useState, useEffect } from 'react'
import { useStore } from '../../lib/store'
import { api } from '../../lib/api'
import { Youtube, Globe, Type, Sparkles, ArrowRight, Link2 } from 'lucide-react'

export default function RecipeInput() {
  const [url, setUrl] = useState('')
  const [loading, setLoading] = useState(false)
  const { session_id, setScreen, reset } = useStore()
  // Default to false so the user can see and interact with the connect card
  const [auth, setAuth] = useState(false)
  const [isConnecting, setIsConnecting] = useState(false)
  const [isConnected, setIsConnected] = useState(false)

  // useEffect(() => {
  //   if (session_id) {
  //       api.checkAuth(session_id).then(res => setAuth(res.authenticated)).catch(() => setAuth(false))
  //   }
  // }, [session_id])

  const handleConnect = async () => {
    setIsConnecting(true)
    try {
      const res = await api.getLoginUrl(session_id)
      
      // In mock mode, the backend returns a URL containing mock_auth=success
      if (res.url.includes('mock_auth=success')) {
        setIsConnecting(false)
        setIsConnected(true)
        setTimeout(() => {
          setAuth(true)
        }, 1500)
      } else {
        window.location.href = res.url
      }
    } catch (e) {
      console.error(e)
      setIsConnecting(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!url.trim()) return
    setLoading(true)
    reset() 
    try {
      await api.processRecipe(session_id, url)
      setScreen('progress')
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const detectInputType = (input: string) => {
    const lower = input.toLowerCase()
    if (lower.includes('youtube.com') || lower.includes('youtu.be')) return 'youtube'
    if (lower.startsWith('http')) return 'blog'
    if (input.length > 10) return 'text'
    return null
  }

  const inputType = detectInputType(url)

  if (!auth) {
    return (
      <div className="flex flex-col items-center justify-center mt-16 animate-fade-in">
        <div className="swiggy-card p-10 text-center max-w-md">
          {/* Swiggy-style connect card */}
          <div className="w-16 h-16 bg-swiggy-50 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Link2 className="w-8 h-8 text-swiggy" />
          </div>
          <h2 className="text-2xl font-bold text-brand-dark mb-2">Connect Instamart</h2>
          <p className="text-brand-subtle text-sm mb-8 leading-relaxed">
            Link your Swiggy account so we can search products, build your cart, and place orders on Instamart.
          </p>
          <button 
            onClick={handleConnect} 
            disabled={isConnecting || isConnected}
            className={`w-full py-3.5 text-base rounded-xl font-semibold transition-all duration-300 flex items-center justify-center gap-2 ${
              isConnected 
                ? 'bg-green-500 text-white shadow-lg shadow-green-500/20' 
                : 'swiggy-btn-primary'
            }`}
          >
            {isConnecting ? (
              <>
                <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Connecting...
              </>
            ) : isConnected ? (
              <>
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                </svg>
                Connected Successfully
              </>
            ) : (
              'Connect Swiggy Account'
            )}
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-2xl mx-auto mt-10 animate-fade-in">
      {/* Hero */}
      <div className="text-center mb-10">
        <div className="inline-flex items-center gap-2 bg-swiggy-50 text-swiggy-700 px-4 py-2 rounded-full text-sm font-medium mb-5">
          <Sparkles className="w-4 h-4" />
          AI-Powered Grocery Agent
        </div>
        <h2 className="text-4xl font-bold text-brand-dark mb-3 leading-tight">
          What are we cooking<br />today?
        </h2>
        <p className="text-brand-subtle text-base">
          Paste any recipe source — we'll build your Instamart cart automatically.
        </p>
      </div>

      {/* Input Card */}
      <div className="swiggy-card p-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <input
              type="text"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="Paste a YouTube URL, blog link, or type a recipe..."
              className="swiggy-input pr-12 text-lg"
            />
            {inputType && (
              <div className="absolute right-4 top-1/2 -translate-y-1/2">
                {inputType === 'youtube' && <Youtube className="w-5 h-5 text-red-500" />}
                {inputType === 'blog' && <Globe className="w-5 h-5 text-blue-500" />}
                {inputType === 'text' && <Type className="w-5 h-5 text-brand-subtle" />}
              </div>
            )}
          </div>

          {/* Quick examples */}
          <div className="flex flex-wrap gap-2">
            <span className="text-xs text-brand-muted">Try:</span>
            <button
              type="button"
              onClick={() => setUrl('https://www.youtube.com/watch?v=9WXinXCkJoI')}
              className="text-xs text-swiggy hover:text-swiggy-700 underline underline-offset-2 transition"
            >
              Butter Chicken (YouTube)
            </button>
            <span className="text-xs text-brand-muted">•</span>
            <button
              type="button"
              onClick={() => setUrl('Make dal tadka for 4 people. Need 200g toor dal, 2 tomatoes, 1 onion, 1 tsp cumin, 1 tsp turmeric, 1 tbsp ghee, salt to taste.')}
              className="text-xs text-swiggy hover:text-swiggy-700 underline underline-offset-2 transition"
            >
              Dal Tadka (text)
            </button>
          </div>

          <button
            type="submit"
            disabled={loading || !url.trim()}
            className="swiggy-btn-primary w-full py-4 text-lg flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Processing...
              </>
            ) : (
              <>
                Cook This
                <ArrowRight className="w-5 h-5" />
              </>
            )}
          </button>
        </form>
      </div>

      {/* Feature pills */}
      <div className="flex flex-wrap justify-center gap-3 mt-8">
        {[
          { icon: '🎥', label: 'YouTube Videos' },
          { icon: '📝', label: 'Recipe Blogs' },
          { icon: '✍️', label: 'Plain Text' },
          { icon: '🛒', label: 'Auto Cart Build' },
          { icon: '🧠', label: 'AI Optimization' },
        ].map(f => (
          <div key={f.label} className="flex items-center gap-1.5 bg-white text-brand-subtle text-xs px-3 py-2 rounded-full border border-brand-border shadow-card">
            <span>{f.icon}</span>
            {f.label}
          </div>
        ))}
      </div>
    </div>
  )
}
