# InstaChef AI - Cooking Commerce Agent

InstaChef AI turns any YouTube cooking video, blog URL, or recipe text into a real Swiggy Instamart grocery cart.

## Prerequisites
- Python 3.12
- Node.js 20+
- Docker (for Redis)

## How to run locally

**Step 1 — Start Redis:**
```bash
docker run -d --name redis -p 6379:6379 redis:7-alpine
```

**Step 2 — Backend setup:**
```bash
cd backend
python -m venv venv
source venv/bin/activate  # (Windows: venv\Scripts\activate)
pip install -r requirements.txt
```

**Step 3 — Add your API keys to backend/.env**
Fill in all values shown in the `.env` file template, specially `ANTHROPIC_API_KEY`.
*(Note: MOCK_MCP=true is set by default for local testing without Swiggy credentials)*

**Step 4 — Start backend:**
```bash
cd backend
uvicorn app.main:app --reload --port 8000
```

**Step 5 — Frontend setup (new terminal):**
```bash
cd frontend
npm install
npm run dev
```

**Step 6 — Open browser:**
Navigate to [http://localhost:3000](http://localhost:3000)

**Step 7 — Connect Swiggy account:**
Click "Connect Swiggy Account" and complete OAuth with your personal Swiggy account (In Mock mode, this instantly authenticates).

**Step 8 — Run the demo:**
Paste this URL: `https://www.youtube.com/watch?v=9WXinXCkJoI`
(Hebbars Kitchen Butter Chicken — reliable transcript, popular recipe)
Click "Cook This →"
Watch the pipeline run
Review the cart
Click "Confirm & Place Order"
Watch live tracking

## Demo Data Seeding
Run `python backend/scripts/seed_demo_cache.py` to pre-cache demo transcriptions and ensure the pipeline is consistently fast.
