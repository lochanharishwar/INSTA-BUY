import json
import os
from typing import Dict, Any, List
import structlog
import numpy as np
from sentence_transformers import SentenceTransformer
import faiss

logger = structlog.get_logger()

def load_ingredients() -> List[Dict]:
    path = os.path.join(os.path.dirname(__file__), "..", "data", "ingredients.json")
    with open(path, "r") as f:
        return json.load(f)

logger.info("normalizer.loading_db", status="started")
ingredients_db = load_ingredients()

# ─── SEMANTIC VECTOR SEARCH SETUP ──────────────────────────────────────────────
logger.info("normalizer.initializing_semantic_search", status="started", model="all-MiniLM-L6-v2")
model = SentenceTransformer('all-MiniLM-L6-v2')

# Build the FAISS index
index_to_db_item = []
documents = []

# To ensure the highest accuracy, we embed the canonical name and all variants
for db_ing in ingredients_db:
    docs_to_add = [db_ing["canonical"]] + db_ing.get("variants", [])
    for d in docs_to_add:
        # Lowercase for consistency
        documents.append(d.lower())
        index_to_db_item.append(db_ing)

# Encode all documents into dense vectors
doc_embeddings = model.encode(documents, convert_to_numpy=True)
dimension = doc_embeddings.shape[1]

# Create FAISS L2 distance index
faiss_index = faiss.IndexFlatL2(dimension)
faiss_index.add(doc_embeddings)
logger.info("normalizer.semantic_search_ready", status="complete", docs_count=len(documents))


def _find_ingredient_match(raw_name: str, canonical_name: str) -> Dict | None:
    """
    Find the best matching ingredient in the DB using Semantic Vector Search.
    Mathematically measures the conceptual distance between the query and known ingredients.
    """
    raw = raw_name.lower().strip()
    canon = canonical_name.lower().strip()

    # Strategy 1: Exact canonical match (O(1) fast path)
    for db_ing in ingredients_db:
        if db_ing["canonical"] == canon:
            return db_ing

    # Strategy 2: Semantic Vector Search
    queries = [canon]
    if raw and raw != canon:
        queries.append(raw)
        
    query_embeddings = model.encode(queries, convert_to_numpy=True)
    
    # We want the absolute best match across all queries
    best_dist = float('inf')
    best_item = None
    
    # k=1 gives us the single closest semantic match in vector space
    distances, indices = faiss_index.search(query_embeddings, k=1)
    
    for i, (dist_arr, idx_arr) in enumerate(zip(distances, indices)):
        dist = dist_arr[0]
        idx = idx_arr[0]
        
        # Lower distance is better in L2. 
        # A threshold of 1.2 is generally a safe semantic boundary for MiniLM-L6-v2.
        if dist < best_dist and dist <= 1.2: 
            best_dist = dist
            best_item = index_to_db_item[idx]
            
    return best_item


def normalize_ingredients(recipe_ingredients: List[Any], serving_size: int) -> List[Dict]:
    """
    Normalize extracted ingredients into searchable terms with gram quantities.
    Uses Semantic Vector Search for highest match accuracy.
    """
    normalized = []
    match_count = 0
    semantic_count = 0
    unmatched_count = 0

    for ing in recipe_ingredients:
        raw = ing.raw_name.lower()
        canon = ing.canonical_name.lower()

        match = _find_ingredient_match(raw, canon)

        if match:
            search_term = match["search_term"]
            match_count += 1
            if match["canonical"] != canon:
                semantic_count += 1
        else:
            # No match found — fallback to canonical name as search term
            search_term = canon
            unmatched_count += 1

        # ─── Unit conversion to grams ─────────────────────────────
        q = ing.quantity
        unit = ing.unit.lower().strip()
        grams = None

        if unit in ["g", "grams", "gram", "ml", "milliliters"]:
            grams = q
        elif unit in ["kg", "kilogram", "kilograms"]:
            grams = q * 1000
        elif unit in ["l", "litre", "liter", "litres", "liters"]:
            grams = q * 1000
        elif unit in ["tbsp", "tablespoon", "tablespoons"]:
            grams = q * 15
        elif unit in ["tsp", "teaspoon", "teaspoons"]:
            grams = q * 5
        elif unit in ["cups", "cup"]:
            grams = q * 200
        elif unit in ["pinch", "pinches"]:
            grams = q * 1
        elif unit in ["pieces", "piece", "nos", "number", "whole"]:
            # For whole items (onion, tomato etc.), estimate grams
            PIECE_WEIGHTS = {
                "onion": 150, "tomato": 120, "potato": 180,
                "green chilli": 5, "garlic": 5, "ginger": 10,
                "lemon": 50, "lime": 40, "egg": 60,
                "banana": 120, "apple": 180, "carrot": 80,
                "bay leaf": 1, "cardamom": 1, "cloves": 1,
                "cinnamon": 3,
            }
            weight = PIECE_WEIGHTS.get(canon, 100)
            grams = q * weight
        else:
            # Unknown unit — estimate from DB if possible
            if match and match.get("default_grams_per_tsp"):
                grams = q * match["default_grams_per_tsp"]

        normalized.append({
            "original_ingredient_id": ing.id,
            "search_term": search_term,
            "quantity_grams": grams,
            "quantity_display": f"{q} {unit}",
            "unit_display": unit,
            "ingredient_name": ing.canonical_name,
            "is_optional": getattr(ing, "is_optional", False),
            "category": getattr(ing, "category", "other"),
            "matched_in_db": match is not None,
        })

    logger.info("normalizer.complete",
                total=len(normalized),
                db_matched=match_count,
                semantic_rescues=semantic_count,
                unmatched=unmatched_count)

    return normalized
