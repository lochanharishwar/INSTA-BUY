import json
import hashlib
import re
import structlog
from openai import AsyncOpenAI
from redis import Redis
from app.config import settings
from pydantic import BaseModel, Field
from typing import List, Optional

logger = structlog.get_logger()

redis_client = Redis.from_url(settings.REDIS_URL, decode_responses=True)

RECIPE_CACHE_TTL = 86400  # 24 hours


class Ingredient(BaseModel):
    id: str
    raw_name: str
    canonical_name: str
    quantity: float
    unit: str
    preparation_note: Optional[str] = None
    is_optional: bool = False
    category: str



class RecipeSchema(BaseModel):
    recipe_name: str
    cuisine_type: str
    serving_size: int
    prep_time_minutes: int
    cook_time_minutes: int
    equipment_needed: List[str]
    dietary_tags: List[str]
    confidence_score: float
    ingredients: List[Ingredient]


SYSTEM_PROMPT = (
    "You are a precise recipe extraction engine. "
    "Extract structured recipe data from the provided content. "
    "Rules:\n"
    "1. Separate preparation from ingredient (e.g., 'finely chopped onions' → canonical_name: 'onion', preparation_note: 'finely chopped').\n"
    "2. Use standard units: gram, ml, teaspoon, tablespoon, cup, piece, pinch.\n"
    "3. For vague quantities ('some', 'to taste'), use practical defaults (1 pinch, 0.5 teaspoon).\n"
    "4. Use canonical English names in canonical_name field.\n"
    "5. Categories: Spices, Produce, Dairy, Protein, Pantry, Oil, Grain, Herbs.\n"
    "6. Generate a UUID-style string for each ingredient id.\n"
    "You MUST return a valid JSON object matching the schema below. No markdown formatting, just raw JSON."
)

SCHEMA_TEMPLATE = """{
  "recipe_name": "string",
  "cuisine_type": "string",
  "serving_size": 4,
  "prep_time_minutes": 0,
  "cook_time_minutes": 0,
  "equipment_needed": ["string"],
  "dietary_tags": ["string"],
  "confidence_score": 0.85,
  "ingredients": [
    {
      "id": "ing-1",
      "raw_name": "string",
      "canonical_name": "string",
      "quantity": 0.0,
      "unit": "string",
      "preparation_note": "string or null",
      "is_optional": false,
      "category": "string"
    }
  ]
}"""


async def understand_recipe(content: str) -> RecipeSchema:
    """
    Parse raw recipe content into structured RecipeSchema using LLM.
    Results are cached in Redis to avoid re-processing identical content.
    """
    cache_key = f"recipe_v2:{hashlib.sha256(content.encode()).hexdigest()}"
    cached = redis_client.get(cache_key)
    if cached:
        logger.info("understander.cache_hit")
        data = json.loads(cached)
        return RecipeSchema(**data)

    client = AsyncOpenAI(
        base_url="https://integrate.api.nvidia.com/v1",
        api_key=settings.NVIDIA_API_KEY
    )

    user_prompt = f"Schema:\n{SCHEMA_TEMPLATE}\n\nContent:\n{content[:4000]}"

    logger.info("understander.generating", content_length=len(user_prompt))

    # Fast path: streaming to avoid NVIDIA endpoint timeouts on sync requests
    completion = await client.chat.completions.create(
        model="meta/llama-3.1-8b-instruct",
        messages=[
            {"role": "user", "content": f"{SYSTEM_PROMPT}\n\n{user_prompt}"}
        ],
        temperature=0.1,
        max_tokens=4096,
        stream=True
    )

    response_text = ""
    async for chunk in completion:
        if not chunk.choices:
            continue
        if chunk.choices[0].delta.content is not None:
            response_text += chunk.choices[0].delta.content

    # Extract JSON block
    match = re.search(r'```(?:json)?\s*(.*?)```', response_text, re.DOTALL)
    if match:
        response_text = match.group(1).strip()
    else:
        # Fallback to brace finding
        start = response_text.find('{')
        end = response_text.rfind('}')
        if start >= 0 and end >= 0:
            response_text = response_text[start:end+1]

    # Cache the successful parse
    data = json.loads(response_text)
    result = RecipeSchema(**data)
    
    redis_client.setex(cache_key, RECIPE_CACHE_TTL, json.dumps(data))

    logger.info("understander.complete",
                 recipe=result.recipe_name,
                 ingredients=len(result.ingredients),
                 confidence=result.confidence_score)

    if result.confidence_score < 0.5:
        raise Exception("RECIPE_CONFIDENCE_LOW")

    return result
